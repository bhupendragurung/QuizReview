﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizReviewApplication.Domain.Enum
{
    public enum SkillType
    {
        EntryLevel = 1,
        Intermediate = 2,
        Advanced = 3
    }
}
