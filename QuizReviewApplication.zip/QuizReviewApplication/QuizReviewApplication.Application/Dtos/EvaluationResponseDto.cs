﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizReviewApplication.Application.Dtos
{
    public class EvaluationResponseDto
    {
        public int Score { get; set; }
        public string Feedback { get; set; }
    }
}
